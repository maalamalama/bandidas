using System;
using System.Text; 



class MainClass {

 public static int wrzutu(int kasa)
  {
   Console.WriteLine("ile chcesz wrzucić pieniędzy? na razie masz "+kasa);
   int temp = Convert.ToInt32(Console.ReadLine());
   Console.WriteLine("masz " + (kasa+temp) + " kasy, jeśli chcesz wrzucić jeszcze raz wpisz tak, jeśli nie, wpisz cokolwiek");
   return kasa+temp;
  }

  public static int gramy(int kasa, string[] be)
{
if (kasa<=0) {
  Console.WriteLine("nie stać Cię na granie");
  return kasa;
}
Console.WriteLine("wciśnij klawisz aby zagrać");
Console.ReadKey();
Console.Clear();
Random random = new Random();
kasa--;
int a = random.Next(7) +1;
int b = random.Next(7) +1;
int c = random.Next(7) +1; 
Console.WriteLine("  " + be[a-1] + be[b-1] + be[c-1]);
Console.WriteLine("->" + be[a] + be[b] + be[c] + "<-");
Console.WriteLine("  " + be[a+1] + be[b+1] + be[c+1]);
if (a==b && b==c) {Console.WriteLine("wygranko!!!");
kasa+=1000000;}
else {
  Console.WriteLine("przegranko :(");
  
  }
Console.WriteLine("masz " + kasa + " kasy");
Console.WriteLine("jeśli chcesz zagrać jeszcze raz wpisz tak, jeśli nie, wpisz cokolwiek");
return kasa;
}


  public static void Main (string[] args) {
    string[] beben =  new string[10] {"🎉 ", "❤ ","🍒 ","⭐ ","🍆 ","🎂 ","💰 ","🍐 ","🎉 ", "❤ "};
    // 🍆❤🍒⭐🍐💰🎉🎂
    string czy = "tak";

    int kasa = 0;

         while (czy=="tak") {
         kasa = wrzutu(kasa);
         czy = Console.ReadLine();}

  Console.WriteLine("teraz będziemy grali");
    
    czy = "tak";
        while (czy=="tak") {
          kasa = gramy(kasa, beben);
          czy = Console.ReadLine();}

  }
}